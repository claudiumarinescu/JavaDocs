CREATE VIEW V_$RESOURCE AS select "ADDR","TYPE","ID1","ID2" from v$resource
/
