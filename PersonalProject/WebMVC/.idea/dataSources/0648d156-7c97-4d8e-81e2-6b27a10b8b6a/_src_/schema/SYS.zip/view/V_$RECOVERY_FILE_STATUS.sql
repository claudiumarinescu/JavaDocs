CREATE VIEW V_$RECOVERY_FILE_STATUS AS select "FILENUM","FILENAME","STATUS" from v$recovery_file_status
/
