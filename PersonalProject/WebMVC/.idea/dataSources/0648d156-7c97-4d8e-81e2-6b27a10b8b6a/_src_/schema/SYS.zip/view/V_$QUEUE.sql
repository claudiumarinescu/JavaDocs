CREATE VIEW V_$QUEUE AS select "PADDR","TYPE","QUEUED","WAIT","TOTALQ" from v$queue
/
