CREATE VIEW V_$DETACHED_SESSION AS select "INDX","PG_NAME","SID","SERIAL#","PID" from v$detached_session
/
