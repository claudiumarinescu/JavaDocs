CREATE VIEW V_$PX_PROCESS_SYSSTAT AS select "STATISTIC","VALUE" from v$px_process_sysstat
/
