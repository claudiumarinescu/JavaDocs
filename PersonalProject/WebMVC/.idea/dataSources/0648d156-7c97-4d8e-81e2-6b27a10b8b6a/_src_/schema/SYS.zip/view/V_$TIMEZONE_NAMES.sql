CREATE VIEW V_$TIMEZONE_NAMES AS select "TZNAME","TZABBREV" from v$timezone_names
/
