CREATE VIEW GV_$PGASTAT AS select "INST_ID","NAME","VALUE","UNIT" from gv$pgastat
/
