CREATE VIEW V_$SGASTAT AS select "POOL","NAME","BYTES" from v$sgastat
/
