CREATE VIEW V_$BLOCKING_QUIESCE AS select "SID" from v$blocking_quiesce
/
