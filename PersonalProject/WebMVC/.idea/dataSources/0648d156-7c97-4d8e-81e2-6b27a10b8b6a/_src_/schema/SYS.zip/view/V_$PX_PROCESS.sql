CREATE VIEW V_$PX_PROCESS AS select "SERVER_NAME","STATUS","PID","SPID","SID","SERIAL#" from v$px_process
/
