CREATE VIEW V_$STATNAME AS select "STATISTIC#","NAME","CLASS","STAT_ID" from v$statname
/
